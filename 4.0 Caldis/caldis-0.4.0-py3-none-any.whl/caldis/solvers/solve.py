import numpy as np

from caldis.core.dof import preflight        # au lieu de check_dof, check_startpoint
from caldis.solvers.homotopy import solve_homotopy
from caldis.solvers.newton import newton


def _direct_newton(system, tol=1e-8):
    """Global damped-Newton from the current start (system.x0()); no continuation.

    Reads the starts via system.x0(), so a failed attempt (which only mutates the
    live .value) leaves the starts intact for the homotopy fallback."""
    def F(x):
        system.set_x(x)
        return np.asarray(system.residuals(), dtype=float)
    return newton(F, system.x0(), scale=system.scales(), bounds=system.bounds(),
                  ftol=tol, xtol=tol)


def solve(system, steps=3, verbose=True, show_homotopy=False,
          diagnostics=True, raise_on_fail=False, strict_physical=False,
          try_newton_first=True):
    if not system._assembled:
        system.assemble()

    # Stages 1-3 (DOF + start evaluable + sanity) -> shared preflight
    if not preflight(system, verbose=verbose, raise_on_fail=raise_on_fail):
        return None

    # Stage 4: solve. Newton-first from the (autostart) seed, homotopy as fallback.
    sol = None
    if try_newton_first:
        sol = _direct_newton(system)
        if verbose:
            tag = "ok" if sol.success else "failed -> fallback to homotopy"
            print(f"  direct Newton: {tag} "
                  f"({sol.nit} it, |F_scaled|={getattr(sol, 'res_scaled', float('nan')):.1e})")
    if sol is None or not sol.success:
        sol = solve_homotopy(system, steps=steps, verbose=show_homotopy)

    if sol.success:
        if verbose:
            fs = getattr(sol, "res_scaled", None)
            acc = f"|F_scaled|={fs:.1e}" if fs is not None else "converged"
            print(f"✓ SOLVED ({acc})")

        failed = system.physical_check(verbose=verbose)
        sol.physical = (len(failed) == 0)
        if failed and strict_physical:
            sol.success = False
            sol.message += " | NON-PHYSICAL (temperature cross)"

    else:
        if verbose:
            print(f"✗ FAILED: {sol.message}")
        if diagnostics:
            from caldis.core.diagnostics import convergence_report, jacobian_report
            convergence_report(system, sol)
            if "singul" in sol.message.lower():
                jacobian_report(system)
            if verbose:
                print("  -> re-anchor the variable(s) named above (set_start_port), "
                      "then solve again.")
        if raise_on_fail:
            raise RuntimeError(f"solve failed: {sol.message}")

    # ensure the system state always reflects sol.x, so a user's manual
    # inspection after solve() matches what the report showed (success or fail).
    system.set_x(sol.x)                      # state reflects the last solution
    for c in system.components:
        _update_outputs_recursive(c)
    return sol


def _update_outputs_recursive(comp):
    """Fill outputs on a component and its children (composites)."""
    try:
        comp.update_outputs()
    except Exception:
        pass                                 # a degenerate stop state may be uncomputable
    for child in comp.children:
        _update_outputs_recursive(child)