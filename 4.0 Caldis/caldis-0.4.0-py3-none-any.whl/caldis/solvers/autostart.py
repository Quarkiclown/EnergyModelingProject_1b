"""Automatic start-point propagation for a System.

Rationale
---------
Most of the start values a user must otherwise hint by hand are *not* genuinely
unknown: pressures and mass flows are (almost) linear and fully implied by the
boundary specs, the value-bearing constraints and the local relations of each
component (a cooler has a known dp, a heat exchanger has dp=0, mass is conserved
in series, a valve is isenthalpic...). Only temperatures / enthalpies are truly
nonlinear and may still need an occasional hint.

This module fills the mechanical part automatically:

  * each quantity carries a PROVENANCE (who set its start);
  * propagation only ever writes into a still-DEFAULT quantity, reading from
    quantities of higher provenance -> it never clobbers a user choice;
  * propagation is a fixpoint over direction-agnostic RULES: connection rules
    (a.p=b.p, a.mdot=-b.mdot, a.h=b.h) and per-component rules. Each rule fires
    only when all its inputs are known and its output is still DEFAULT, so the
    execution order does not matter and both "directions" of a relation coexist
    without adding any equation to the model.

Usage
-----
    from caldis.solvers.autostart import autostart, fix_port

    fix_port(sys_, comp1.out, p=P2)              # 1 residual + seeded start
    fix_port(sys_, feed.port, p=P1, T=T0, mdot=-1)
    ...
    autostart(sys_, verbose=True)                # replaces init_starts()
    sol = solve(sys_)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

# ------------------------------------------------------------------ provenance
DEFAULT, PROPAGATED, HINT, BOUNDARY = 0, 1, 2, 3   # strictly increasing priority

_ATTR = {"p": "_p", "mdot": "_mdot", "h": "_h"}    # port attr -> Variable object


def _var(port, attr):
    """Return the Variable object backing a port quantity ('p'|'mdot'|'h')."""
    return getattr(port, _ATTR[attr])


# ------------------------------------------------------------------ rule model
@dataclass
class Rule:
    """One directed start-propagation rule.

    needs : list of (port, attr) that must already be resolved for the rule to fire
    sets  : (port, attr) this rule assigns, only if still DEFAULT
    fn    : () -> float, computed from the current .start of the needed quantities
    """
    needs: list
    sets: tuple
    fn: Callable[[], float]


# ----------------------------------------------------- per-component rule sets
def _component_rules(comp):
    """Return the start-propagation rules for a single component, by type.

    These encode ONLY structural local relations (dp, mass conservation,
    isenthalpic...) and are listed in both directions; the engine fires whichever
    direction has its inputs already known. They are NOT model equations.
    """
    cls = type(comp).__name__
    R = []

    def pass_mdot(a, b):
        # mass conservation across a 2-port element: a.mdot = -b.mdot (both ways)
        R.append(Rule([(a, "mdot")], (b, "mdot"), lambda: -_var(a, "mdot").start))
        R.append(Rule([(b, "mdot")], (a, "mdot"), lambda: -_var(b, "mdot").start))

    def equal_p(a, b):
        R.append(Rule([(a, "p")], (b, "p"), lambda: _var(a, "p").start))
        R.append(Rule([(b, "p")], (a, "p"), lambda: _var(b, "p").start))

    if cls == "SimpleHeater":
        i, o = comp.inl, comp.out
        dp = comp.params.get("dp", 0.0)
        R.append(Rule([(i, "p")], (o, "p"), lambda: _var(i, "p").start - dp))
        R.append(Rule([(o, "p")], (i, "p"), lambda: _var(o, "p").start + dp))
        pass_mdot(i, o)

    elif cls in ("Compressor", "Turbine"):
        # pressure comes from a constraint/boundary, not from the machine itself
        pass_mdot(comp.inl, comp.out)

    elif cls == "Valve":
        i, o = comp.inl, comp.out
        pass_mdot(i, o)
        # isenthalpic: out.h = in.h (both ways)
        R.append(Rule([(i, "h")], (o, "h"), lambda: _var(i, "h").start))
        R.append(Rule([(o, "h")], (i, "h"), lambda: _var(o, "h").start))

    elif cls in ("SizingHX", "RatingHX"):
        equal_p(comp.hot_in, comp.hot_out)
        equal_p(comp.cold_in, comp.cold_out)
        pass_mdot(comp.hot_in, comp.hot_out)
        pass_mdot(comp.cold_in, comp.cold_out)

    elif cls == "Mixer":
        a, b, o = comp.in1, comp.in2, comp.out
        for x, y in ((a, b), (a, o), (b, o)):
            equal_p(x, y)
        # mass: in1 + in2 + out = 0  -> any port from the other two
        R.append(Rule([(a, "mdot"), (b, "mdot")], (o, "mdot"),
                      lambda: -(_var(a, "mdot").start + _var(b, "mdot").start)))
        R.append(Rule([(a, "mdot"), (o, "mdot")], (b, "mdot"),
                      lambda: -(_var(a, "mdot").start + _var(o, "mdot").start)))
        R.append(Rule([(b, "mdot"), (o, "mdot")], (a, "mdot"),
                      lambda: -(_var(b, "mdot").start + _var(o, "mdot").start)))

    elif cls == "FlashTank":
        i, v, l = comp.inl, comp.vap, comp.liq
        for x, y in ((i, v), (i, l), (v, l)):
            equal_p(x, y)
        R.append(Rule([(v, "mdot"), (l, "mdot")], (i, "mdot"),
                      lambda: -(_var(v, "mdot").start + _var(l, "mdot").start)))
        R.append(Rule([(i, "mdot"), (l, "mdot")], (v, "mdot"),
                      lambda: -(_var(i, "mdot").start + _var(l, "mdot").start)))
        R.append(Rule([(i, "mdot"), (v, "mdot")], (l, "mdot"),
                      lambda: -(_var(i, "mdot").start + _var(v, "mdot").start)))

    # FluidBoundary and anything unknown contribute no propagation rules.
    return R


def _connection_rules(system):
    """Rules from the port-to-port connections: equal p and h, opposite mdot.

    The mdot coupling is skipped on a close_loop connection (its mdot residual is
    intentionally dropped from the model, so it must not propagate either)."""
    R = []
    for conn in system.connections:
        a, b = conn.a, conn.b
        for attr in ("p", "h"):
            R.append(Rule([(a, attr)], (b, attr),
                          lambda a=a, attr=attr: _var(a, attr).start))
            R.append(Rule([(b, attr)], (a, attr),
                          lambda b=b, attr=attr: _var(b, attr).start))
        if not getattr(conn, "close_loop", False):
            R.append(Rule([(a, "mdot")], (b, "mdot"),
                          lambda a=a: -_var(a, "mdot").start))
            R.append(Rule([(b, "mdot")], (a, "mdot"),
                          lambda b=b: -_var(b, "mdot").start))
    return R


# ------------------------------------------------------------------- fix_port
def fix_port(system, port, p=None, T=None, h=None, mdot=None):
    """Impose port quantities AND record them as start anchors.

    For every quantity given it (i) adds the residual that fixes it and (ii)
    records a BOUNDARY-level start anchor that autostart() will seed. Replaces an
    opaque add_constraint(lambda: port.p - value) so the value stays readable by
    the propagation. Temperature is fixed on the port's own backend."""
    anchors = system.__dict__.setdefault("_fix_anchors", [])
    name = port.owner.local_name

    if p is not None:
        system.add_constraint(lambda port=port, v=p: port.p - v, f"{name}.{port.name}.p")
        anchors.append((port, "p", float(p)))
    if mdot is not None:
        system.add_constraint(lambda port=port, v=mdot: port.mdot - v, f"{name}.{port.name}.mdot")
        anchors.append((port, "mdot", float(mdot)))
    if h is not None:
        system.add_constraint(lambda port=port, v=h: port.h - v, f"{name}.{port.name}.h")
        anchors.append((port, "h", float(h)))
    if T is not None:
        system.add_constraint(lambda port=port, v=T: port.T - v, f"{name}.{port.name}.T")
        anchors.append((port, "T", float(T)))   # resolved to h at seeding time
    return system


# ------------------------------------------------------------------- anchors
def _seed_anchors(system, prov):
    """Seed the start values that are known a priori, tagging their provenance.

    Sources: FluidBoundary specs and set_start_port hints (HINT), fix_port
    anchors (BOUNDARY). A T anchor is converted to h on the port's backend."""
    def seed(port, attr, value, level):
        if attr == "T":
            be = port.backend
            value = be.h_pt(_var(port, "p").start, value)
            attr = "h"
        var = _var(port, attr)
        if level >= prov.get(id(var), DEFAULT):
            var.start = float(value)
            prov[id(var)] = level

    # FluidBoundary specs -> BOUNDARY (imposed by the model itself)
    for c in system.components:
        specs = getattr(c, "params", {}).get("specs")
        if not specs:
            continue
        port = c.ports[0]
        if "p" in specs:
            seed(port, "p", specs["p"], BOUNDARY)
        if "mdot" in specs:
            seed(port, "mdot", specs["mdot"], BOUNDARY)
        if "h" in specs:
            seed(port, "h", specs["h"], BOUNDARY)
        elif "T" in specs and "p" in specs:
            seed(port, "T", specs["T"], BOUNDARY)

    # set_start_port hints -> HINT (kept for the legitimate nonlinear T hints)
    for (port, p, T, h, mdot) in getattr(system, "_port_hints", []):
        if p is not None:    seed(port, "p", p, HINT)
        if mdot is not None: seed(port, "mdot", mdot, HINT)
        if h is not None:    seed(port, "h", h, HINT)
        elif T is not None:  seed(port, "T", T, HINT)

    # set_start side/component hints -> HINT (coarser cousin of set_start_port)
    for (comp, p, T, mdot, side) in getattr(system, "_start_hints", []):
        for port in comp.ports:
            if side is not None and not port.name.startswith(side + "_"):
                continue
            if p is not None:    seed(port, "p", p, HINT)
            if T is not None:    seed(port, "T", T, HINT)
            if mdot is not None:
                m = -mdot if port.name.endswith("out") else mdot
                seed(port, "mdot", m, HINT)

    # fix_port anchors -> BOUNDARY
    for (port, attr, value) in getattr(system, "_fix_anchors", []):
        seed(port, attr, value, BOUNDARY)


# ------------------------------------------------------------------- autostart
def autostart(system, T_default=283.15, verbose=False):
    """Fill every port start automatically, then load the values.

    Call this INSTEAD of init_starts(), after building the system and declaring
    the boundary specs / fix_port anchors (and any set_start_port T hint)."""
    if not system._assembled:
        system.assemble()

    prov = {}                          # id(Variable) -> provenance level
    _seed_anchors(system, prov)

    rules = _connection_rules(system)
    for c in system.components:
        rules += _component_rules(c)

    # fixpoint: fire any rule whose inputs are known and whose target is DEFAULT
    changed, n_prop = True, 0
    while changed:
        changed = False
        for r in rules:
            tport, tattr = r.sets
            tvar = _var(tport, tattr)
            if prov.get(id(tvar), DEFAULT) > DEFAULT:
                continue               # already anchored or propagated
            if all(prov.get(id(_var(p, a)), DEFAULT) > DEFAULT for p, a in r.needs):
                val = r.fn()
                if val is None:
                    continue
                tvar.start = float(val)
                prov[id(tvar)] = PROPAGATED
                changed = True
                n_prop += 1

    # fallback: ports still without an evaluable (p, h) get an in-domain default
    n_fallback = 0
    for c in system.components:
        for port in c.ports:
            be = getattr(port, "backend", None)
            pv, hv = _var(port, "p"), _var(port, "h")
            if be is not None and (prov.get(id(pv), DEFAULT) == DEFAULT
                                   or prov.get(id(hv), DEFAULT) == DEFAULT):
                p0, h0 = be.default_state(T_default)
                if prov.get(id(pv), DEFAULT) == DEFAULT:
                    pv.start = p0; n_fallback += 1
                if prov.get(id(hv), DEFAULT) == DEFAULT:
                    hv.start = h0

    # also let any component seed its internal (non-port) starts, as init_starts does
    for c in system.components:
        if hasattr(c, "seed_internal_starts"):
            c.seed_internal_starts()

    system.set_x(system.x0())
    if verbose:
        n_default = sum(1 for c in system.components for port in c.ports
                        for a in ("p", "mdot", "h")
                        if prov.get(id(_var(port, a)), DEFAULT) == DEFAULT)
        print(f"autostart: {n_prop} propagated, {n_fallback} pressure fallbacks, "
              f"{n_default} port-quantities left at default")
    return system